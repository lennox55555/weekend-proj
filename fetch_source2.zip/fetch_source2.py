import os
import csv
import io
import time
import boto3
import requests
from datetime import datetime

# ← your full US-wide airport list
AIRPORTS = [
    # Major hubs
    'KJFK','KLAX','KORD','KATL','KDFW','KDEN','KSEA','KMIAA',
    'KBOS','KLGA','KEWR','KSFO','KIAD','KDCA','KBWI','KPHL',
    'KCLT','KPHX','KLAS','KMSP','KDET','KMCO','KTPA','KSAN',
    'KSTL','KCVG','KCMH','KPIT','KMEM','KBNA','KAUS','KSAT',
    'KHOU','KIAH','KMSY','KRDU','KRIC','KORF','KFLL','KPBI',
    'KJAX','KTUL','KOKC','KOMA','KDSM','KMCI','KLIT','KSHV',
    # West Coast
    'KPDX','KOAK','KSJC','KBUR','KLGB','KONT','KSMF','KSAN',
    # Mountain/Southwest
    'KSLC','KABQ','KCOS','KBIL','KBZN','KJAC','KFCA','KGEG',
    # East Coast
    'KPVD','KBDL','KALB','KBGR','KPWM','KMHT','KBTV','KSYR',
    # Southeast
    'KATL','KBHM','KHSV','KMGM','KMOB','KPNS','KTLH','KJAX',
    # Midwest
    'KMKE','KMDT','KGRR','KLAN','KFWA','KIND','KEVV','KSDF'
]

def handler(event, context):
    BUCKET = os.environ["BUCKET"]
    KEY    = os.environ["FLIGHTAWARE_API_KEY"]
    BASE   = "https://aeroapi.flightaware.com/aeroapi"
    HEAD   = {"x-apikey": KEY}

    all_rows = []

    for airport in AIRPORTS:
        try:
            # 1) fetch departures
            dep = requests.get(
                f"{BASE}/airports/{airport}/flights/departures",
                headers=HEAD, params={"max_pages": 2}
            )
            print(f"{airport} departures → {dep.status_code}")
            if dep.status_code != 200:
                if dep.status_code == 429:
                    time.sleep(10)
                continue

            deps = dep.json().get("departures", [])[:10]
            for f in deps:
                prog = f.get("progress_percent", 0)
                if not (2 < prog < 95):
                    continue

                for ident in (f.get("fa_flight_id"), f.get("ident")):
                    if not ident:
                        continue
                    tr = requests.get(f"{BASE}/flights/{ident}/track", headers=HEAD)
                    print(f"  track {ident} → {tr.status_code}")
                    if tr.status_code != 200:
                        time.sleep(0.3)
                        continue
                    pts = tr.json().get("positions", [])
                    if len(pts) <= 5:
                        break

                    now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
                    for i,p in enumerate(pts,1):
                        ts = p.get("timestamp")
                        all_rows.append({
                            "collection_time": now,
                            "flight_ident":   f["ident"],
                            "aircraft_type":  f.get("aircraft_type","Unknown"),
                            "origin":         airport,
                            "destination":    (f.get("destination") or {}).get("code","Unknown"),
                            "point_number":   i,
                            "position_time":  datetime.utcfromtimestamp(ts).isoformat() if ts else "",
                            "latitude":       p.get("latitude"),
                            "longitude":      p.get("longitude"),
                            "altitude_ft":    p.get("altitude"),
                            "groundspeed_kts":p.get("groundspeed"),
                            "track_deg":      p.get("track"),
                            "total_points":   len(pts)
                        })
                    break  # don’t try the other identifier

                time.sleep(0.3)
            time.sleep(0.8)

        except Exception as e:
            print(f"Error on {airport}: {e}")
            continue

    if not all_rows:
        print("❌ No track data collected.")
        return

    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=all_rows[0].keys())
    writer.writeheader()
    writer.writerows(all_rows)

    date_key = datetime.utcnow().date().isoformat()
    boto3.client("s3").put_object(
        Bucket=BUCKET,
        Key=f"raw/source2/{date_key}.csv",
        Body=buf.getvalue()
    )
    print(f"✅ Wrote {len(all_rows)} rows to raw/source2/{date_key}.csv")
