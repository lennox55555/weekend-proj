import os, csv, io, boto3, requests
from datetime import datetime

def handler(event, context):
    BUCKET = os.environ["BUCKET"]
    KEY    = os.environ["OPENWEATHER_API_KEY"]
    LAT    = os.environ["LAT"]
    LON    = os.environ["LON"]

    # Free‐tier Current Weather call
    resp = requests.get(
        "https://api.openweathermap.org/data/2.5/weather",
        params={"lat": LAT, "lon": LON, "appid": KEY, "units": "metric"}
    )
    resp.raise_for_status()
    data = resp.json()

    row = {
        "timestamp": int(datetime.utcnow().timestamp()),
        "temp": data["main"]["temp"],
        "feels_like": data["main"]["feels_like"],
        "pressure": data["main"]["pressure"],
        "humidity": data["main"]["humidity"],
        "wind_speed": data["wind"]["speed"],
        "weather_main": data["weather"][0]["main"],
        "weather_desc": data["weather"][0]["description"]
    }

    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=row.keys())
    writer.writeheader()
    writer.writerow(row)

    date_key = datetime.utcnow().date().isoformat()
    boto3.client("s3").put_object(
        Bucket=BUCKET,
        Key=f"raw/source1/{date_key}.csv",
        Body=buf.getvalue()
    )
