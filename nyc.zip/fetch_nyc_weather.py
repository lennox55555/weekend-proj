import os
import csv
import json
import boto3
from datetime import datetime
from urllib.request import urlopen, Request
from urllib.error import HTTPError, URLError

def handler(event, context):
    BUCKET = os.environ['BUCKET']
    API_KEY = os.environ['OPENWEATHER_API_KEY']
    LAT = os.environ['LAT']
    LON = os.environ['LON']

    # Fetch 24-hour forecast
    url = (
        f"https://api.openweathermap.org/data/2.5/onecall"
        f"?lat={LAT}&lon={LON}"
        f"&exclude=current,minutely,daily,alerts"
        f"&appid={API_KEY}&units=imperial"
    )

    try:
        req = Request(url)
        with urlopen(req) as resp:
            data = json.load(resp)
    except HTTPError as e:
        raise RuntimeError(f"OpenWeather HTTP error {e.code}: {e.reason}")
    except URLError as e:
        raise RuntimeError(f"OpenWeather URL error: {e.reason}")

    hourly = data.get('hourly', [])[:24]

    # Build CSV rows
    rows = []
    for h in hourly:
        dt = datetime.utcfromtimestamp(h['dt']).isoformat()
        rows.append([
            dt,
            h.get('temp'),
            h.get('feels_like'),
            h.get('humidity'),
            h.get('pressure'),
            h.get('wind_speed'),
            h['weather'][0]['description']
        ])

    date_str = datetime.utcnow().strftime('%Y-%m-%d')
    local_path = f"/tmp/{date_str}.csv"
    s3_key    = f"raw/nyc/{date_str}.csv"

    # Write and upload
    with open(local_path, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['datetime','temp','feels_like','humidity','pressure','wind_speed','description'])
        writer.writerows(rows)

    boto3.client('s3').upload_file(local_path, BUCKET, s3_key)
