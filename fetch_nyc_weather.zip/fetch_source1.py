import os, io, csv
import boto3, requests
from datetime import datetime, timedelta

def handler(event, context):
    BUCKET = os.environ["BUCKET"]
    KEY    = os.environ["OPENWEATHER_API_KEY"]
    LAT    = float(os.environ["LAT"])
    LON    = float(os.environ["LON"])

    # target = yesterday UTC calendar date
    target_date = datetime.utcnow().date() - timedelta(days=1)
    rows = []

    for hour in range(24):
        dt = datetime.combine(target_date, datetime.min.time()) + timedelta(hours=hour)
        ts = int(dt.timestamp())
        resp = requests.get(
            "https://api.openweathermap.org/data/2.5/onecall/timemachine",
            params={
              "lat": LAT,
              "lon": LON,
              "dt": ts,
              "appid": KEY,
              "units": "imperial"
            }
        )
        resp.raise_for_status()
        data = resp.json().get("current", {})

        rows.append({
            "timestamp":      dt.isoformat(),
            "temp_F":         data.get("temp"),
            "feels_like_F":   data.get("feels_like"),
            "humidity_%":     data.get("humidity"),
            "pressure_hPa":   data.get("pressure"),
            "wind_speed_mph": data.get("wind_speed"),
            "weather_desc":   (data.get("weather") or [{}])[0].get("description","")
        })

    # Write CSV to S3
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=rows[0].keys())
    w.writeheader()
    w.writerows(rows)

    key = f"raw/nyc/{target_date.isoformat()}.csv"
    boto3.client("s3").put_object(Bucket=BUCKET, Key=key, Body=buf.getvalue())
    print(f"Wrote 24 rows to {key}")
    return {"rows": len(rows)}
